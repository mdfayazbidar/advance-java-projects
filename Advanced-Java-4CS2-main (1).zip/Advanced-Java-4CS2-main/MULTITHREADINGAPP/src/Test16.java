/*
 * use synchronization 
to print 
all even numbers by first thread
all odd numbers by second thread
 */
public class Test16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
