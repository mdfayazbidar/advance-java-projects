/*
Presidency collects data related to existing employees 
working  since last 5 years 
and data's for the candidates applied for various positions.
Create two threads to do the tasks above.

The data's related to existing employees :
1. name, position, salary, exp-in years
The data's related to candidates
1. name, qualification, experience
CA1 : 
Gaduputi Treteswar Naidu - 20211cse0067 -marks10
ashish singh 20221lcs0002 - marks -10
Harihanth 20211cse0076- marks -10
srinivas 20211cse0090- marks -9
Kasturi Deepak 20211cse0112-8
lakshman pavan kumar-20211cse0091-10 marks
remaining students those are present : 5 marks
afreen 
*
public class Test11_SurpriseTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
